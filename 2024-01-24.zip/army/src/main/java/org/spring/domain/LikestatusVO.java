package org.spring.domain;

import lombok.Data;

@Data
public class LikestatusVO {
	private int lno;
	private int cno;
	private int bno;
	private String nickname;
	private int likestatus;
}
